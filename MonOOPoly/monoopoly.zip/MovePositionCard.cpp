#include "MovePositionCard.h"
#include "Board.h"

MovePositionCard::MovePositionCard(int tiles)
{
    this->tiles = tiles;
}

Card* MovePositionCard::clone() const
{
    return new MovePositionCard(*this);
}

void MovePositionCard::applyEffect(Player& player) const
{
    Board::setId(player, player.getId() + tiles);
}
